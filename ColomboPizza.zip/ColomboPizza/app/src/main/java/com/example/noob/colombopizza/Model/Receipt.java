package com.example.noob.colombopizza.Model;

import java.util.List;

public class Receipt {
    public List<Order> items;
    public String totalcost;
}
