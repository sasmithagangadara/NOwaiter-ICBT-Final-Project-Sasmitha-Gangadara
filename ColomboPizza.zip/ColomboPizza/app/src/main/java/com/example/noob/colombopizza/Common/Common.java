package com.example.noob.colombopizza.Common;

import com.example.noob.colombopizza.Model.User;

public class Common {
    public static User currentUser;
    public static final String DELETE = "Delete";
}
